package com.utn.apiRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
